simple_actor = {
  color= {1, 0, 1},
  alpha = 0.5,
  size = 5,
  name = "SimpleActor",
}